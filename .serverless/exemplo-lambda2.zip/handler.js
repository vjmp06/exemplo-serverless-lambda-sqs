const AWS = require("aws-sdk");
const sqs = new AWS.SQS({
    region: "us-east-1",
});
exports.hello = (event, context, callback) => {
  const response = {
    statusCode: 200,
    body: JSON.stringify({
        message: "SQS event processed.",
        input: event,
    }),
};
console.info("event:", JSON.stringify(event));
callback(null, response);
};